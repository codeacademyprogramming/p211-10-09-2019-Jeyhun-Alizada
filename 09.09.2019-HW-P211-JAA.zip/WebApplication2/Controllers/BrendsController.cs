﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.DAL;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class BrendsController : Controller
    {
        private readonly ASPTraning_Context _context;
        public BrendsController(ASPTraning_Context context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.Brends.ToList());
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(string brendName)
        {
            Brend brend = new Brend { Name = brendName };
            await _context.Brends.AddAsync(brend);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Delete(int Id)
        {
            Brend brend = await _context.Brends.FindAsync(Id);
            if (brend == null) return null;
            _context.Brends.Remove(brend);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}