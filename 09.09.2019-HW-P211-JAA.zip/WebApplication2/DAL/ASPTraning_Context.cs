﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.DAL
{
    public class ASPTraning_Context : DbContext
    {
        public ASPTraning_Context(DbContextOptions<ASPTraning_Context> options) : base(options)
        {

        }
        public DbSet<Brend> Brends { get; set;}
        public DbSet<CarModel> CarModels { get; set;}
    }
}
