﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using P211_ASP.Models;

namespace P211_ASP.DAL
{
    public class P211_Asp_Context : DbContext
    {
        public P211_Asp_Context(DbContextOptions<P211_Asp_Context> options) : base(options)
        {   
        }

        public DbSet<Group> Groups { get; set; }
        public DbSet<Student> Students { get; set; }
    }
}
