﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P211_ASP.Models;

namespace P211_ASP.Controllers
{
    public class HomeController : Controller
    {
        private readonly List<Group> groups = new List<Group>
        {
            new Group { Id = 1, Name = "P211"},
            new Group { Id = 2, Name = "V211"},
            new Group { Id = 3, Name = "P200"},
            new Group { Id = 4, Name = "P110"},
            new Group { Id = 5, Name = "V300"}
        };

        private readonly List<Student> students = new List<Student>
        {
            new Student { Firstname = "Sebuhi", Lastname = "Heziyev", GroupId = 1},
            new Student { Firstname = "Amelie 2", Lastname = "Ameliyeva", GroupId = 2},
            new Student { Firstname = "Amelie 3", Lastname = "Ameliyeva", GroupId = 1},
            new Student { Firstname = "Amelie 4", Lastname = "Ameliyeva", GroupId = 1},
            new Student { Firstname = "Amelie 5", Lastname = "Ameliyeva", GroupId = 1},
            new Student { Firstname = "Amelie 6", Lastname = "Ameliyeva", GroupId = 1},
            new Student { Firstname = "Qedim", Lastname = "Babayev", GroupId = 1},
            new Student { Firstname = "Reshad", Lastname = "Huseynov", GroupId = 1},
            new Student { Firstname = "Ramiz", Lastname = "Usubov", GroupId = 3}
        };

        public IActionResult Index()
        {
            return View(students);
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
