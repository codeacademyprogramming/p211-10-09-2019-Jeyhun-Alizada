﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P211_ASP.DAL;
using P211_ASP.Models;

namespace P211_ASP.Controllers
{
    public class GroupsController : Controller
    {
        private readonly P211_Asp_Context _context;

        public GroupsController(P211_Asp_Context context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Groups.ToList());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(string groupname)
        {
            Group group = new Group { Name = groupname };

            await _context.Groups.AddAsync(group);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            Group group = await _context.Groups.FindAsync(id);

            if (group == null) return NotFound();

            _context.Groups.Remove(group);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}