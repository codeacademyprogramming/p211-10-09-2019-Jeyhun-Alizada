﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace P211_ASP.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }

        [NotMapped]
        public string Fullname { get { return Firstname + " " + Lastname; } }
        public int GroupId { get; set; }
        public virtual Group Group { get; set; } //navigation property
    }
}
